// JavaScript для конструктора форм (админка)
(function ($) {
    'use strict';

    $(document).ready(function () {
        // Функция для определения автоматических ограничений
        function getAutoRestrictions(fieldName, fieldLabel, fieldType) {
            const nameLower = fieldName.toLowerCase();
            const labelLower = fieldLabel.toLowerCase();
            let pattern = '';
            let minlength = '';

            // Логин
            if (nameLower.includes('login') || nameLower.includes('username') || labelLower.includes('логин')) {
                pattern = '^[a-zA-Z0-9]{6,}$';
                minlength = '6';
            }
            // Пароль
            else if (nameLower.includes('password') || nameLower.includes('pass') || labelLower.includes('пароль')) {
                minlength = '8';
            }
            // ФИО
            else if (nameLower.includes('fio') || nameLower.includes('full_name') || labelLower.includes('фио') || labelLower.includes('ф.и.о.') || labelLower.includes('ф и о')) {
                pattern = '^[а-яА-ЯёЁ]+[\\s\\-][а-яА-ЯёЁ]+[\\s\\-][а-яА-ЯёЁ]+$';
            }
            // Телефон
            else if (nameLower.includes('phone') || nameLower.includes('tel') || labelLower.includes('телефон')) {
                pattern = '^8\\(\\d{3}\\)\\d{3}-\\d{2}-\\d{2}$';
            }

            return { pattern, minlength };
        }

        // Добавление нового поля
        $('#add-field-btn').on('click', function () {
            var container = $('#fields-container');
            var fieldIndex = container.children().length;

            var fieldHtml = `
                <div class="field-editor" data-index="${fieldIndex}">
                    <div class="field-header">
                        <h4>Новое поле</h4>
                        <button type="button" class="remove-field button button-small">Удалить</button>
                    </div>
                    <div class="field-inputs">
                        <input type="text" name="fields[${fieldIndex}][label]" 
                               placeholder="Название поля (например: Логин)" 
                               class="field-label-input" required>
                        <input type="text" name="fields[${fieldIndex}][name]" 
                               placeholder="Имя поля (англ., например: username)" 
                               class="field-name-input" required>
                        <select name="fields[${fieldIndex}][type]" class="field-type-select">
                            <option value="text">Текст</option>
                            <option value="password">Пароль</option>
                            <option value="email">Email</option>
                            <option value="tel">Телефон</option>
                            <option value="number">Число</option>
                            <option value="textarea">Текстовая область</option>
                            <option value="select">Выпадающий список</option>
                            <option value="checkbox">Галочка</option>
                            <option value="radio">Радио-кнопки</option>
                            <option value="date">Дата</option>
                        </select>
                        <input type="text" name="fields[${fieldIndex}][placeholder]" 
                               placeholder="Подсказка в поле">
                        
                        <div class="field-params">
                            <div class="field-option" data-show="select,radio">
                                <input type="text" name="fields[${fieldIndex}][options]" 
                                       placeholder="Варианты через запятую (для select/radio)">
                            </div>
                            <div class="field-option" data-show="text,password,email,tel,number,textarea">
                                <input type="number" name="fields[${fieldIndex}][minlength]" 
                                       placeholder="Мин. длина (авто)" min="0" class="field-minlength-input">
                                <input type="number" name="fields[${fieldIndex}][maxlength]" 
                                       placeholder="Макс. длина" min="1">
                            </div>
                            <div class="field-option" data-show="text,password,tel">
                                <input type="text" name="fields[${fieldIndex}][pattern]" 
                                       placeholder="Регулярное выражение (авто)" 
                                       class="field-pattern-input"
                                       title="Автоматически заполняется для стандартных полей">
                            </div>
                        </div>
                        
                        <label class="field-required">
                            <input type="checkbox" name="fields[${fieldIndex}][required]" value="1"> Обязательное поле
                        </label>
                    </div>
                </div>`;

            container.append(fieldHtml);

            // Инициализация нового поля
            var newField = container.children().last();
            initFieldEditor(newField);
        });

        // Инициализация поля редактора
        function initFieldEditor($field) {
            var $typeSelect = $field.find('.field-type-select');
            var $labelInput = $field.find('.field-label-input');
            var $nameInput = $field.find('.field-name-input');
            var $minlengthInput = $field.find('.field-minlength-input');
            var $patternInput = $field.find('.field-pattern-input');

            // Обновление ограничений
            function updateAutoRestrictions() {
                var fieldName = $nameInput.val();
                var fieldLabel = $labelInput.val();
                var fieldType = $typeSelect.val();

                var restrictions = getAutoRestrictions(fieldName, fieldLabel, fieldType);

                if (restrictions.pattern && (!$patternInput.val() || $patternInput.val().includes('авто'))) {
                    $patternInput.val(restrictions.pattern);
                } else if (!restrictions.pattern && fieldType === 'password') {
                    $patternInput.val('');
                }

                if (restrictions.minlength && (!$minlengthInput.val() || $minlengthInput.val() === '0')) {
                    $minlengthInput.val(restrictions.minlength);
                }
            }

            // События
            $labelInput.on('input', updateAutoRestrictions);
            $nameInput.on('input', updateAutoRestrictions);
            $typeSelect.on('change', function () {
                updateAutoRestrictions();
                updateFieldParamsVisibility($(this));
            });

            // Инициализация
            updateAutoRestrictions();
            updateFieldParamsVisibility($typeSelect);
        }

        // Обновление видимости параметров поля
        function updateFieldParamsVisibility($select) {
            var $fieldInputs = $select.closest('.field-inputs');
            var fieldType = $select.val();

            $fieldInputs.find('.field-option').hide();
            $fieldInputs.find('.field-option[data-show*="' + fieldType + '"]').show();
        }

        // Удаление поля
        $(document).on('click', '.remove-field', function () {
            $(this).closest('.field-editor').remove();
            updateFieldNumbers();
        });

        // Обновление нумерации полей
        function updateFieldNumbers() {
            $('#fields-container .field-editor').each(function (index) {
                var $header = $(this).find('.field-header h4');
                var fieldName = $(this).find('input[name$="[label]"]').val() || 'Новое поле';
                $header.text('Поле ' + (index + 1) + ': ' + fieldName);
            });
        }

        // Обновление номера при изменении label
        $(document).on('input', 'input[name$="[label]"]', function () {
            var $fieldEditor = $(this).closest('.field-editor');
            var fieldIndex = $fieldEditor.index();
            var $header = $fieldEditor.find('.field-header h4');
            $header.text('Поле ' + (fieldIndex + 1) + ': ' + $(this).val());
        });

        // Изменение типа существующих полей
        $(document).on('change', '.field-type-select', function () {
            updateFieldParamsVisibility($(this));
        });

        // Инициализация существующих полей
        $('#fields-container .field-editor').each(function () {
            initFieldEditor($(this));
        });

        // Обновление превью шорткода
        $('input[name="form_id"]').on('input', function () {
            $('#shortcode-preview').text($(this).val() || 'ваш_id');
        });

        // Для формы входа
        $('input[name="form_id"]').on('input', function () {
            $('#login-shortcode-preview').text($(this).val() || 'ваш_id');
        });
    });
})(jQuery);