// Автоформатирование телефона
(function($) {
    'use strict';
    
    $(document).ready(function() {
        // Автоформатирование телефона
        $('.phone-input, input[type="tel"], input[name*="phone"], input[name*="tel"]').each(function() {
            var $input = $(this);
            var lastValue = $input.val();
            
            // Обработчик ввода
            $input.on('input', function(e) {
                var value = $(this).val().replace(/\D/g, '');
                
                if (!value) {
                    lastValue = '';
                    return;
                }
                
                if (!value.startsWith('8')) {
                    if (value.length <= 10) {
                        value = '8' + value;
                    } else {
                        value = '8' + value.substring(0, 10);
                    }
                }
                
                value = value.substring(0, 11);
                
                if (value.startsWith('8')) {
                    var formatted = '8';
                    
                    if (value.length > 1) formatted += '(' + value.substring(1, 4);
                    if (value.length >= 4) formatted += ')' + value.substring(4, 7);
                    if (value.length >= 7) formatted += '-' + value.substring(7, 9);
                    if (value.length >= 9) formatted += '-' + value.substring(9, 11);
                    
                    if (formatted !== lastValue) {
                        $(this).val(formatted);
                        lastValue = formatted;
                        
                        var cursorPos = formatted.length;
                        $(this)[0].setSelectionRange(cursorPos, cursorPos);
                    }
                }
            });
            
            // Обработчик вставки
            $input.on('paste', function(e) {
                e.preventDefault();
                var pastedText = (e.originalEvent.clipboardData || window.clipboardData).getData('text');
                var numbers = pastedText.replace(/\D/g, '');
                
                if (numbers) {
                    var phone = numbers;
                    if (!phone.startsWith('8')) {
                        if (phone.startsWith('7')) {
                            phone = '8' + phone.substring(1);
                        } else {
                            phone = '8' + phone;
                        }
                    }
                    
                    phone = phone.substring(0, 11);
                    
                    if (phone.startsWith('8')) {
                        var formatted = '8';
                        if (phone.length > 1) formatted += '(' + phone.substring(1, 4);
                        if (phone.length >= 4) formatted += ')' + phone.substring(4, 7);
                        if (phone.length >= 7) formatted += '-' + phone.substring(7, 9);
                        if (phone.length >= 9) formatted += '-' + phone.substring(9, 11);
                        
                        $(this).val(formatted);
                        lastValue = formatted;
                    }
                }
            });
            
            // Обработчик клавиш
            $input.on('keydown', function(e) {
                var allowedKeys = [
                    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                    'Backspace', 'Delete', 'Tab', 'ArrowLeft', 'ArrowRight',
                    'Home', 'End', 'Enter'
                ];
                
                if (e.ctrlKey && ['v', 'V', 'a', 'A'].includes(e.key)) {
                    return true;
                }
                
                if (!allowedKeys.includes(e.key)) {
                    e.preventDefault();
                    return false;
                }
                return true;
            });
            
            // Обработчик фокуса
            $input.on('focus', function() {
                if (!$(this).val()) {
                    $(this).val('8(');
                    lastValue = '8(';
                    $(this)[0].setSelectionRange(2, 2);
                } else {
                    var cursorPos = $(this).val().length;
                    $(this)[0].setSelectionRange(cursorPos, cursorPos);
                }
            });
        });
        
        // Валидация ФИО в реальном времени
        $('input[name*="fio"], input[name*="full_name"]').on('blur', function() {
            var value = $(this).val().trim();
            if (value) {
                var words = value.split(/\s+/).filter(function(word) {
                    return word.length > 0;
                });
                if (words.length !== 3) {
                    this.setCustomValidity('ФИО должно содержать ровно 3 слова (Фамилия Имя Отчество)');
                    this.reportValidity();
                } else {
                    this.setCustomValidity('');
                }
            }
        }).on('input', function() {
            this.setCustomValidity('');
        });
    });
})(jQuery);