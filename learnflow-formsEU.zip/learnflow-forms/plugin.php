<?php

/**
 * Plugin Name: LearnFlow Admin - Конструктор форм
 * Description: Плагин для создания кастомных форм регистрации, входа и управления заявками.
 * Version: 2.0
 * Author: YeakYeakYeak
 * Text Domain: learnflow-forms
 */

// Базовые константы
if (!defined('SA_PLUGIN_DIR')) {
    define('SA_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('SA_PLUGIN_URL')) {
    define('SA_PLUGIN_URL', plugin_dir_url(__FILE__));
}

// Проверка безопасности
if (!defined('ABSPATH')) {
    exit;
}

// Автозагрузка файлов - ПРОВЕРЬТЕ ЧТО ВСЕ ФАЙЛЫ СУЩЕСТВУЮТ!
require_once SA_PLUGIN_DIR . 'includes/activation.php';
require_once SA_PLUGIN_DIR . 'includes/admin-menu.php';
require_once SA_PLUGIN_DIR . 'includes/helpers.php';

// Form builder
require_once SA_PLUGIN_DIR . 'includes/form-builder/dashboard.php';
require_once SA_PLUGIN_DIR . 'includes/form-builder/registration-forms.php';
require_once SA_PLUGIN_DIR . 'includes/form-builder/login-forms.php';

// Shortcodes
require_once SA_PLUGIN_DIR . 'includes/shortcodes/dynamic-shortcodes.php';  // ПЕРВЫМ из shortcodes
require_once SA_PLUGIN_DIR . 'includes/shortcodes/registration.php';
require_once SA_PLUGIN_DIR . 'includes/shortcodes/login.php';
require_once SA_PLUGIN_DIR . 'includes/shortcodes/applications.php';

// Validation
require_once SA_PLUGIN_DIR . 'includes/validation/fio-validation.php';
require_once SA_PLUGIN_DIR . 'includes/validation/phone-validation.php';
require_once SA_PLUGIN_DIR . 'includes/validation/general-validation.php';

// Applications
require_once SA_PLUGIN_DIR . 'includes/applications/admin-panel.php';
require_once SA_PLUGIN_DIR . 'includes/applications/user-forms.php';
require_once SA_PLUGIN_DIR . 'includes/applications/feedback.php';

// Инициализация плагина
add_action('plugins_loaded', 'sa_initialize_plugin');
function sa_initialize_plugin()
{
    // Подключение скриптов и стилей
    add_action('admin_enqueue_scripts', 'sa_admin_scripts');
    add_action('wp_enqueue_scripts', 'sa_frontend_scripts');
}

// Админские скрипты
function sa_admin_scripts($hook)
{
    if (strpos($hook, 'sa_') !== false) {
        wp_enqueue_style('sa-admin-styles', SA_PLUGIN_URL . 'assets/css/admin-styles.css');
        wp_enqueue_script('sa-form-builder', SA_PLUGIN_URL . 'assets/js/form-builder.js', ['jquery'], '1.0', true);
    }
}

// Фронтенд скрипты
function sa_frontend_scripts()
{
    global $post;
    if (is_a($post, 'WP_Post')) {
        if (
            has_shortcode($post->post_content, 'sa_register_') ||
            has_shortcode($post->post_content, 'sa_login_') ||
            has_shortcode($post->post_content, 'sa_application_form') ||
            has_shortcode($post->post_content, 'sa_my_applications')
        ) {

            wp_enqueue_style('sa-frontend-styles', SA_PLUGIN_URL . 'assets/css/frontend-styles.css');
            wp_enqueue_script('sa-phone-mask', SA_PLUGIN_URL . 'assets/js/phone-mask.js', ['jquery'], '1.0', true);
        }
    }
}
