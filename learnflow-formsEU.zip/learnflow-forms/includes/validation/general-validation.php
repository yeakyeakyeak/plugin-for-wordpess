<?php
// ОБЩАЯ ВАЛИДАЦИЯ

// Получение автоматических правил для поля
function sa_get_auto_field_rules($field_name, $field_label) {
    require_once SA_PLUGIN_DIR . 'includes/validation/fio-validation.php';
    require_once SA_PLUGIN_DIR . 'includes/validation/phone-validation.php';
    
    $field_lower_name = strtolower($field_name);
    $field_lower_label = strtolower($field_label);
    
    $rules = ['pattern' => '', 'minlength' => '', 'maxlength' => ''];
    
    // ЛОГИН: латиница и цифры, не менее 6 символов
    if (strpos($field_lower_name, 'login') !== false || 
        strpos($field_lower_name, 'username') !== false ||
        strpos($field_lower_label, 'логин') !== false) {
        $rules['pattern'] = '^[a-zA-Z0-9]{6,}$';
        $rules['minlength'] = '6';
    }
    // ПАРОЛЬ: минимум 8 символов, ЛЮБЫЕ символы
    elseif (strpos($field_lower_name, 'password') !== false ||
            strpos($field_lower_name, 'pass') !== false ||
            strpos($field_lower_label, 'пароль') !== false) {
        $rules['minlength'] = '8';
        // pattern оставляем пустым для пароля
    }
    // ФИО
    elseif (sa_is_fio_field($field_name, $field_label)) {
        $rules['pattern'] = sa_get_fio_pattern();
    }
    // ТЕЛЕФОН
    elseif (sa_is_phone_field($field_name, $field_label)) {
        $rules['pattern'] = sa_get_phone_pattern();
    }
    
    return $rules;
}

// Валидация поля формы
function sa_validate_field($field, $value) {
    $errors = [];
    
    // Валидация обязательных полей
    if ($field['required'] && empty($value)) {
        $errors[] = 'Поле "' . $field['label'] . '" обязательно для заполнения.';
        return $errors;
    }
    
    // Для необязательных пустых полей - пропускаем проверки
    if (empty($value) && !$field['required']) {
        return $errors;
    }
    
    // Проверка минимальной/максимальной длины
    if (!empty($field['minlength']) && strlen($value) < $field['minlength']) {
        $errors[] = 'Поле "' . $field['label'] . '" должно содержать минимум ' . $field['minlength'] . ' символов.';
    }
    
    if (!empty($field['maxlength']) && strlen($value) > $field['maxlength']) {
        $errors[] = 'Поле "' . $field['label'] . '" должно содержать максимум ' . $field['maxlength'] . ' символов.';
    }
    
    // Проверка email
    if ($field['type'] === 'email' && !empty($value)) {
        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Введите корректный email адрес.';
        }
    }
    
    return $errors;
}

// Обработка значения поля
function sa_process_field_value($field, $value) {
    require_once SA_PLUGIN_DIR . 'includes/validation/fio-validation.php';
    require_once SA_PLUGIN_DIR . 'includes/validation/phone-validation.php';
    
    if (sa_is_fio_field($field['name'], $field['label'])) {
        return sa_process_fio_value($value);
    }
    
    if (sa_is_phone_field($field['name'], $field['label'])) {
        return sa_process_phone_value($value);
    }
    
    return $value;
}

// Сбор данных пользователя
function sa_collect_user_data($field, $value, $user_data) {
    $field_lower_label = strtolower($field['label']);
    $field_lower_name = strtolower($field['name']);
    
    $is_user_field = false;
    
    if (($field['type'] === 'text' || $field['type'] === 'email') && 
        (strpos($field_lower_label, 'логин') !== false || 
         strpos($field_lower_name, 'username') !== false ||
         strpos($field_lower_name, 'login') !== false)) {
        $user_data['user_login'] = $value;
        $is_user_field = true;
    }
    elseif ($field['type'] === 'password') {
        $user_data['user_pass'] = $value;
        $is_user_field = true;
    }
    elseif ($field['type'] === 'email' && empty($user_data['user_email'])) {
        $user_data['user_email'] = $value;
        $is_user_field = true;
    }
    
    $user_data['is_user_field'] = $is_user_field;
    return $user_data;
}

// Проверка обязательных полей пользователя
function sa_validate_required_user_fields($user_data) {
    $errors = [];
    
    if (empty($user_data['user_login'])) {
        $errors[] = 'Необходимо добавить поле "Логин" в форму.';
    }
    
    if (empty($user_data['user_pass'])) {
        $errors[] = 'Необходимо добавить поле "Пароль" в форму.';
    }
    
    if (empty($user_data['user_email'])) {
        $errors[] = 'Необходимо добавить поле "Email" в форму.';
    }
    
    return $errors;
}

// Проверка существования пользователя
function sa_check_user_existence($user_data) {
    $errors = [];
    
    if (username_exists($user_data['user_login'])) {
        $errors[] = 'Пользователь с таким логином уже существует.';
    }
    
    if (email_exists($user_data['user_email'])) {
        $errors[] = 'Пользователь с таким email уже существует.';
    }
    
    return $errors;
}

// Регистрация пользователя
function sa_register_user($user_data, $meta_data) {
    $user_id = wp_create_user($user_data['user_login'], $user_data['user_pass'], $user_data['user_email']);
    
    if (!is_wp_error($user_id)) {
        // Сохраняем метаданные
        foreach ($meta_data as $key => $value) {
            update_user_meta($user_id, $key, $value);
        }
        
        // Автоматическая авторизация
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);
        
        return ['success' => true];
    } else {
        return ['success' => false, 'error' => 'Ошибка при регистрации: ' . $user_id->get_error_message()];
    }
}
?>