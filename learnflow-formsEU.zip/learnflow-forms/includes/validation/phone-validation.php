<?php
// ВАЛИДАЦИЯ ТЕЛЕФОНА

// Валидация и форматирование телефона
function sa_validate_phone($value) {
    // Убираем все нецифровые символы
    $clean_phone = preg_replace('/\D/', '', $value);
    
    // Если номер начинается с 7, меняем на 8
    if (strlen($clean_phone) === 11 && $clean_phone[0] === '7') {
        $clean_phone = '8' . substr($clean_phone, 1);
    }
    
    // Проверяем формат: начинается с 8 и имеет 11 цифр
    if (!preg_match('/^8\d{10}$/', $clean_phone)) {
        return ['error' => 'Телефон должен содержать 11 цифр и начинаться с 8 (например: 89191234567)'];
    }
    
    // Форматируем номер
    return ['success' => true, 'value' => sa_format_phone($clean_phone)];
}

// Форматирование телефона
function sa_format_phone($clean_phone) {
    return sprintf(
        '8(%s)%s-%s-%s',
        substr($clean_phone, 1, 3),
        substr($clean_phone, 4, 3),
        substr($clean_phone, 7, 2),
        substr($clean_phone, 9, 2)
    );
}

// Проверка является ли поле телефоном
function sa_is_phone_field($field_name, $field_label) {
    $field_lower_name = strtolower($field_name);
    $field_lower_label = strtolower($field_label);
    
    return (strpos($field_lower_name, 'phone') !== false ||
            strpos($field_lower_name, 'tel') !== false ||
            strpos($field_lower_label, 'телефон') !== false);
}

// Получение регулярного выражения для телефона
function sa_get_phone_pattern() {
    return '^8\(\d{3}\)\d{3}-\d{2}-\d{2}$';
}

// Обработка значения телефона
function sa_process_phone_value($value) {
    $validation = sa_validate_phone($value);
    
    if (isset($validation['success']) && $validation['success']) {
        return $validation['value'];
    }
    
    return $value;
}
?>