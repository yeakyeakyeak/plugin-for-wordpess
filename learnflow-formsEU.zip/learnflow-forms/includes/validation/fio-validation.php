<?php
// ВАЛИДАЦИЯ ФИО

// Валидация ФИО (ровно 3 слова)
function sa_validate_fio($value) {
    // Проверяем что есть ровно 3 слова
    $words = preg_split('/\s+/', trim($value));
    $words = array_filter($words, function($word) {
        return !empty($word);
    });
    
    if (count($words) !== 3) {
        return ['error' => 'ФИО должно содержать ровно 3 слова (Фамилия Имя Отчество)'];
    }
    
    // Проверяем что все слова содержат только кириллицу и дефисы
    foreach ($words as $word) {
        if (!preg_match('/^[а-яА-ЯёЁ\-]+$/u', $word)) {
            return ['error' => 'ФИО должно содержать только кириллицу и дефисы'];
        }
    }
    
    // Автоматическая капитализация
    $words = array_map(function($word) {
        return mb_convert_case($word, MB_CASE_TITLE, 'UTF-8');
    }, $words);
    
    return ['success' => true, 'value' => implode(' ', $words)];
}

// Проверка является ли поле ФИО
function sa_is_fio_field($field_name, $field_label) {
    $field_lower_name = strtolower($field_name);
    $field_lower_label = strtolower($field_label);
    
    return (strpos($field_lower_name, 'fio') !== false ||
            strpos($field_lower_name, 'full_name') !== false ||
            strpos($field_lower_label, 'фио') !== false ||
            strpos($field_lower_label, 'ф.и.о.') !== false ||
            strpos($field_lower_label, 'ф и о') !== false);
}

// Получение регулярного выражения для ФИО
function sa_get_fio_pattern() {
    return '^[а-яА-ЯёЁ]+[\\s\\-][а-яА-ЯёЁ]+[\\s\\-][а-яА-ЯёЁ]+$';
}

// Обработка значения ФИО
function sa_process_fio_value($value) {
    $validation = sa_validate_fio($value);
    
    if (isset($validation['success']) && $validation['success']) {
        return $validation['value'];
    }
    
    return $value; // Возвращаем исходное значение если ошибка
}
?>