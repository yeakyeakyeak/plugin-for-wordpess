<?php
// АДМИН-ПАНЕЛЬ ДЛЯ ЗАЯВОК НА КУРСЫ
function sa_applications_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Требуется права администратора!');
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'survival_applications';

    if (isset($_POST['sa_update_status_nonce']) && wp_verify_nonce($_POST['sa_update_status_nonce'], 'sa_update_status_action')) {
        $app_id = intval($_POST['application_id']);
        $new_status = sanitize_text_field($_POST['new_status']);
        $valid_statuses = ['Новая', 'Идет обучение', 'Обучение завершено'];
        if (in_array($new_status, $valid_statuses)) {
            $wpdb->update($table_name, ['status' => $new_status], ['id' => $app_id]);
        }
    }

    $applications = $wpdb->get_results("SELECT a.*, u.user_login FROM $table_name a LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID ORDER BY a.created_at DESC");

    echo '<div class="wrap"><h1>Заявки на курсы</h1>';
    echo '<table class="wp-list-table widefat fixed striped"><thead><tr>
           <th>ID</th><th>Пользователь</th><th>Курс</th><th>Дата начала</th><th>Способ оплаты</th><th>Статус</th><th>Дата подачи</th><th>Действия</th>
          </tr></thead><tbody>';

    foreach ($applications as $app) {
        $visible_status = $app->status === 'Новая' ? 'Скрыт (Новая)' : $app->status;
        echo '<tr>';
        echo '<td>' . esc_html($app->id) . '</td>';
        echo '<td>' . esc_html($app->user_login) . '</td>';
        echo '<td>' . esc_html($app->course_name) . '</td>';
        echo '<td>' . esc_html(date('d.m.Y', strtotime($app->start_date))) . '</td>';
        echo '<td>' . esc_html($app->payment_method) . '</td>';
        echo '<td>' . esc_html($visible_status) . '</td>';
        echo '<td>' . esc_html(date('d.m.Y H:i', strtotime($app->created_at))) . '</td>';
        echo '<td><form method="post" style="display: inline;">';
        echo '<input type="hidden" name="application_id" value="' . esc_attr($app->id) . '">';
        wp_nonce_field('sa_update_status_action', 'sa_update_status_nonce');
        echo '<select name="new_status">';
        foreach (['Новая', 'Идет обучение', 'Обучение завершено'] as $status) {
            $selected = $app->status === $status ? 'selected' : '';
            echo '<option value="' . esc_attr($status) . '" ' . $selected . '>' . esc_html($status) . '</option>';
        }
        echo '</select> <input type="submit" value="Обновить" class="button button-small">';
        echo '</form></td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}
?>