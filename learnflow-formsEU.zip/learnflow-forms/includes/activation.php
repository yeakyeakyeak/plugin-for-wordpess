<?php
// Создание таблиц при активации
register_activation_hook(__FILE__, 'sa_create_tables');
function sa_create_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    // Таблица заявок на курсы
    $table_apps = $wpdb->prefix . 'survival_applications';
    $sql_apps = "CREATE TABLE $table_apps (
        id MEDIUMINT(9) NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        course_name VARCHAR(255) NOT NULL,
        start_date DATE NOT NULL,
        payment_method VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL DEFAULT 'Новая',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset_collate;";
    
    // Таблица отзывов к заявкам
    $table_feedback = $wpdb->prefix . 'survival_app_feedback';
    $sql_feedback = "CREATE TABLE $table_feedback (
        id MEDIUMINT(9) NOT NULL AUTO_INCREMENT,
        application_id MEDIUMINT(9) NOT NULL,
        feedback_text TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
        PRIMARY KEY (id),
        KEY application_id (application_id)
    ) $charset_collate;";
    
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_apps);
    dbDelta($sql_feedback);
    
    // Создаем опции по умолчанию если их нет
    if (!get_option('sa_registration_forms')) {
        update_option('sa_registration_forms', []);
    }
    
    if (!get_option('sa_login_forms')) {
        update_option('sa_login_forms', []);
    }
}
?>