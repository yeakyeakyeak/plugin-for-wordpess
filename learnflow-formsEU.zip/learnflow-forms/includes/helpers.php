<?php
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ

// Проверка наличия шорткода в контенте
function sa_has_shortcode($shortcode = '') {
    global $post;
    if (is_a($post, 'WP_Post')) {
        return has_shortcode($post->post_content, $shortcode);
    }
    return false;
}

// Безопасный вывод HTML
function sa_safe_html($html) {
    return wp_kses($html, [
        'div' => ['class' => [], 'id' => [], 'style' => []],
        'p' => ['class' => [], 'style' => []],
        'span' => ['class' => [], 'style' => []],
        'input' => ['type' => [], 'name' => [], 'value' => [], 'placeholder' => [], 'required' => [], 'pattern' => [], 'minlength' => [], 'maxlength' => [], 'class' => [], 'id' => [], 'style' => []],
        'textarea' => ['name' => [], 'placeholder' => [], 'required' => [], 'class' => [], 'id' => [], 'style' => [], 'rows' => []],
        'select' => ['name' => [], 'required' => [], 'class' => [], 'id' => [], 'style' => []],
        'option' => ['value' => [], 'selected' => []],
        'button' => ['type' => [], 'class' => [], 'id' => [], 'style' => []],
        'form' => ['method' => [], 'action' => [], 'class' => [], 'id' => [], 'style' => [], 'novalidate' => []],
        'label' => ['for' => [], 'class' => []],
        'a' => ['href' => [], 'class' => [], 'target' => [], 'onclick' => []],
        'h1' => ['class' => []], 'h2' => ['class' => []], 'h3' => ['class' => []], 'h4' => ['class' => []],
        'ul' => ['class' => []], 'ol' => ['class' => []], 'li' => ['class' => []],
        'table' => ['class' => []], 'thead' => [], 'tbody' => [], 'tr' => [], 'th' => [], 'td' => [],
        'code' => [], 'strong' => [], 'em' => [], 'br' => []
    ]);
}

// Логирование действий
function sa_log_action($action, $details = '') {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('LearnFlow Forms: ' . $action . ' - ' . $details);
    }
}

// Получение текущего URL
function sa_current_url() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https://" : "http://";
    return $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
}
?>