<?php
add_action('admin_menu', 'sa_add_form_builder_menu');

function sa_add_form_builder_menu() {
    // Главное меню конструктора форм
    add_menu_page(
        'Конструктор форм', 
        'Конструктор форм', 
        'manage_options', 
        'sa_form_builder', 
        'sa_render_form_builder_page',
        'dashicons-forms',
        30
    );
    
    // Подменю для форм регистрации
    add_submenu_page(
        'sa_form_builder',
        'Формы регистрации',
        'Формы регистрации',
        'manage_options',
        'sa_registration_forms',
        'sa_render_registration_forms_page'
    );
    
    // Подменю для форм входа
    add_submenu_page(
        'sa_form_builder',
        'Формы входа',
        'Формы входа',
        'manage_options',
        'sa_login_forms',
        'sa_render_login_forms_page'
    );
    
    // ОТДЕЛЬНОЕ меню для заявок на курсы
    add_menu_page(
        'Заявки на курсы',
        'Заявки',
        'manage_options',
        'sa_applications',
        'sa_applications_page',
        'dashicons-clipboard',
        31
    );
}
?>