<?php
// VIEW: Страница форм регистрации
?>
<div class="wrap">
    <h1>Формы регистрации</h1>
    
    <div class="sa-forms-container">
        <!-- Редактор формы -->
        <div class="sa-form-editor">
            <h2><?php echo $editing_form ? 'Редактировать форму' : 'Создать новую форму регистрации'; ?></h2>
            
            <form method="post">
                <?php wp_nonce_field('sa_registration_form_save'); ?>
                
                <div class="form-meta">
                    <p>
                        <label><strong>Название формы:</strong><br>
                            <input type="text" name="form_name" 
                                   value="<?php echo $editing_form ? esc_attr($editing_form['name']) : ''; ?>" 
                                   placeholder="Например: Основная форма регистрации" required>
                        </label>
                    </p>
                    
                    <p>
                        <label><strong>ID формы (английскими буквами):</strong><br>
                            <input type="text" name="form_id" 
                                   value="<?php echo $editing_form ? esc_attr($editing_form['id']) : ''; ?>" 
                                   pattern="[a-z0-9_]+" 
                                   placeholder="main_register" required>
                            <br><small>Шорткод будет: <code>[sa_register_<span id="shortcode-preview"><?php echo $editing_form ? esc_html($editing_form['id']) : 'ваш_id'; ?></span>]</code></small>
                        </label>
                    </p>
                </div>
                
                <h3>Поля формы</h3>
                <div class="sa-field-info">
                    <p><strong>Автоматические ограничения для стандартных полей:</strong></p>
                    <ul>
                        <li><strong>Логин:</strong> латиница и цифры, не менее 6 символов</li>
                        <li><strong>Пароль:</strong> минимум 8 символов (любые символы)</li>
                        <li><strong>ФИО:</strong> кириллица, пробелы и дефисы. РОВНО 3 СЛОВА (Фамилия Имя Отчество)</li>
                        <li><strong>Телефон:</strong> формат 8(XXX)XXX-XX-XX</li>
                        <li><strong>Email:</strong> стандартный формат email</li>
                    </ul>
                    <p><em>Ограничения применяются автоматически при совпадении имени или метки поля.</em></p>
                </div>
                
                <div id="fields-container">
                    <?php if ($editing_form && !empty($editing_form['fields'])): ?>
                        <?php foreach ($editing_form['fields'] as $index => $field): ?>
                            <div class="field-editor" data-index="<?php echo $index; ?>">
                                <div class="field-header">
                                    <h4>Поле <?php echo $index + 1; ?>: <?php echo esc_html($field['label']); ?></h4>
                                    <button type="button" class="remove-field button button-small">Удалить</button>
                                </div>
                                <div class="field-inputs">
                                    <input type="text" name="fields[<?php echo $index; ?>][label]" 
                                           placeholder="Название поля (например: Логин)" 
                                           value="<?php echo esc_attr($field['label']); ?>" required>
                                    <input type="text" name="fields[<?php echo $index; ?>][name]" 
                                           placeholder="Имя поля (англ., например: username)" 
                                           value="<?php echo esc_attr($field['name']); ?>" required>
                                    <select name="fields[<?php echo $index; ?>][type]" class="field-type-select">
                                        <option value="text" <?php selected($field['type'], 'text'); ?>>Текст</option>
                                        <option value="password" <?php selected($field['type'], 'password'); ?>>Пароль</option>
                                        <option value="email" <?php selected($field['type'], 'email'); ?>>Email</option>
                                        <option value="tel" <?php selected($field['type'], 'tel'); ?>>Телефон</option>
                                        <option value="number" <?php selected($field['type'], 'number'); ?>>Число</option>
                                        <option value="textarea" <?php selected($field['type'], 'textarea'); ?>>Текстовая область</option>
                                        <option value="select" <?php selected($field['type'], 'select'); ?>>Выпадающий список</option>
                                        <option value="checkbox" <?php selected($field['type'], 'checkbox'); ?>>Галочка</option>
                                        <option value="radio" <?php selected($field['type'], 'radio'); ?>>Радио-кнопки</option>
                                        <option value="date" <?php selected($field['type'], 'date'); ?>>Дата</option>
                                    </select>
                                    <input type="text" name="fields[<?php echo $index; ?>][placeholder]" 
                                           placeholder="Подсказка в поле" 
                                           value="<?php echo esc_attr($field['placeholder']); ?>">
                                    
                                    <!-- Параметры для разных типов полей -->
                                    <div class="field-params">
                                        <div class="field-option" data-show="select,radio">
                                            <input type="text" name="fields[<?php echo $index; ?>][options]" 
                                                   placeholder="Варианты через запятую (для select/radio)" 
                                                   value="<?php echo esc_attr($field['options']); ?>">
                                        </div>
                                        <div class="field-option" data-show="text,password,email,tel,number,textarea">
                                            <input type="number" name="fields[<?php echo $index; ?>][minlength]" 
                                                   placeholder="Мин. длина (авто)" min="0"
                                                   value="<?php echo esc_attr($field['minlength']); ?>">
                                            <input type="number" name="fields[<?php echo $index; ?>][maxlength]" 
                                                   placeholder="Макс. длина" min="1"
                                                   value="<?php echo esc_attr($field['maxlength']); ?>">
                                        </div>
                                        <div class="field-option" data-show="text,password,tel">
                                            <input type="text" name="fields[<?php echo $index; ?>][pattern]" 
                                                   placeholder="Регулярное выражение (авто)" 
                                                   value="<?php echo esc_attr($field['pattern']); ?>"
                                                   title="Автоматически заполняется для стандартных полей">
                                        </div>
                                    </div>
                                    
                                    <label class="field-required">
                                        <input type="checkbox" name="fields[<?php echo $index; ?>][required]" value="1" <?php checked($field['required'], 1); ?>> Обязательное поле
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <button type="button" id="add-field-btn" class="button button-primary">+ Добавить поле</button>
                
                <div class="form-actions">
                    <input type="submit" name="sa_save_registration_form" class="button button-primary button-large" 
                           value="<?php echo $editing_form ? 'Обновить форму' : 'Сохранить форму'; ?>">
                    <?php if ($editing_form): ?>
                        <a href="?page=sa_registration_forms" class="button button-large">Отмена</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <!-- Список форм -->
        <div class="sa-forms-list">
            <h2>Сохранённые формы регистрации</h2>
            
            <?php if (empty($registration_forms)): ?>
                <p>Нет сохранённых форм. Создайте первую форму.</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Название</th>
                            <th>Шорткод</th>
                            <th>Поля</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($registration_forms as $form_id => $form): ?>
                        <tr>
                            <td><strong><?php echo esc_html($form['name']); ?></strong></td>
                            <td><code>[sa_register_<?php echo esc_html($form_id); ?>]</code></td>
                            <td><?php echo count($form['fields']); ?> полей</td>
                            <td><?php echo date('d.m.Y', strtotime($form['created'])); ?></td>
                            <td>
                                <a href="?page=sa_registration_forms&edit=<?php echo esc_attr($form_id); ?>" class="button button-small">Редактировать</a>
                                <a href="?page=sa_registration_forms&delete=<?php echo esc_attr($form_id); ?>" 
                                   class="button button-small" 
                                   onclick="return confirm('Удалить форму «<?php echo esc_js($form['name']); ?>»?')">Удалить</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
            <div class="sa-form-info">
                <h3>Как использовать:</h3>
                <ol>
                    <li>Создайте форму с нужными полями</li>
                    <li>Для стандартных полей ограничения применяются автоматически</li>
                    <li>Вставьте шорткод на страницу: <code>[sa_register_ID_формы]</code></li>
                    <li>Добавьте ссылку "Еще не зарегистрированы? Регистрация" на форму входа</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('fields-container');
    const addBtn = document.getElementById('add-field-btn');
    const idInput = document.querySelector('input[name="form_id"]');
    const previewSpan = document.getElementById('shortcode-preview');
    let fieldIndex = <?php echo $editing_form ? count($editing_form['fields']) : 0; ?>;
    
    // Обновление превью шорткода
    if (idInput && previewSpan) {
        idInput.addEventListener('input', function() {
            previewSpan.textContent = this.value || 'ваш_id';
        });
    }
    
    // Функция для определения автоматических ограничений
    function getAutoRestrictions(fieldName, fieldLabel, fieldType) {
        const nameLower = fieldName.toLowerCase();
        const labelLower = fieldLabel.toLowerCase();
        let pattern = '';
        let minlength = '';
        
        // Логин
        if (nameLower.includes('login') || nameLower.includes('username') || labelLower.includes('логин')) {
            pattern = '^[a-zA-Z0-9]{6,}$';
            minlength = '6';
        }
        // Пароль - НЕ ставим pattern! Только minlength
        else if (nameLower.includes('password') || nameLower.includes('pass') || labelLower.includes('пароль')) {
            minlength = '8';
            // pattern оставляем пустым
        }
        // ФИО: кириллица, пробелы и дефисы, РОВНО 3 СЛОВА
        else if (nameLower.includes('fio') || nameLower.includes('full_name') || labelLower.includes('фио') || labelLower.includes('ф.и.о.') || labelLower.includes('ф и о')) {
            pattern = '^[а-яА-ЯёЁ]+[\\s\\-][а-яА-ЯёЁ]+[\\s\\-][а-яА-ЯёЁ]+$';
        }
        // Телефон
        else if (nameLower.includes('phone') || nameLower.includes('tel') || labelLower.includes('телефон')) {
            pattern = '^8\\(\\d{3}\\)\\d{3}-\\d{2}-\\d{2}$';
        }
        
        return { pattern, minlength };
    }
    
    // Добавление нового поля
    addBtn.addEventListener('click', function() {
        const index = fieldIndex++;
        const fieldHtml = `
            <div class="field-editor" data-index="${index}">
                <div class="field-header">
                    <h4>Новое поле</h4>
                    <button type="button" class="remove-field button button-small">Удалить</button>
                </div>
                <div class="field-inputs">
                    <input type="text" name="fields[${index}][label]" 
                           placeholder="Название поля (например: Логин)" 
                           class="field-label-input" required>
                    <input type="text" name="fields[${index}][name]" 
                           placeholder="Имя поля (англ., например: username)" 
                           class="field-name-input" required>
                    <select name="fields[${index}][type]" class="field-type-select">
                        <option value="text">Текст</option>
                        <option value="password">Пароль</option>
                        <option value="email">Email</option>
                        <option value="tel">Телефон</option>
                        <option value="number">Число</option>
                        <option value="textarea">Текстовая область</option>
                        <option value="select">Выпадающий список</option>
                        <option value="checkbox">Галочка</option>
                        <option value="radio">Радио-кнопки</option>
                        <option value="date">Дата</option>
                    </select>
                    <input type="text" name="fields[${index}][placeholder]" 
                           placeholder="Подсказка в поле">
                    
                    <div class="field-params">
                        <div class="field-option" data-show="select,radio">
                            <input type="text" name="fields[${index}][options]" 
                                   placeholder="Варианты через запятую (для select/radio)">
                        </div>
                        <div class="field-option" data-show="text,password,email,tel,number,textarea">
                            <input type="number" name="fields[${index}][minlength]" 
                                   placeholder="Мин. длина (авто)" min="0" class="field-minlength-input">
                            <input type="number" name="fields[${index}][maxlength]" 
                                   placeholder="Макс. длина" min="1">
                        </div>
                        <div class="field-option" data-show="text,password,tel">
                            <input type="text" name="fields[${index}][pattern]" 
                                   placeholder="Регулярное выражение (авто)" 
                                   class="field-pattern-input"
                                   title="Автоматически заполняется для стандартных полей">
                        </div>
                    </div>
                    
                    <label class="field-required">
                        <input type="checkbox" name="fields[${index}][required]" value="1"> Обязательное поле
                    </label>
                </div>
            </div>`;
        
        container.insertAdjacentHTML('beforeend', fieldHtml);
        
        // Добавляем обработчики для нового поля
        const newField = container.lastElementChild;
        const typeSelect = newField.querySelector('.field-type-select');
        const labelInput = newField.querySelector('.field-label-input');
        const nameInput = newField.querySelector('.field-name-input');
        const minlengthInput = newField.querySelector('.field-minlength-input');
        const patternInput = newField.querySelector('.field-pattern-input');
        
        // Функция обновления ограничений
        function updateAutoRestrictions() {
            const fieldName = nameInput.value;
            const fieldLabel = labelInput.value;
            const fieldType = typeSelect.value;
            
            const restrictions = getAutoRestrictions(fieldName, fieldLabel, fieldType);
            
            // Устанавливаем автоматические значения только если поля пустые
            if (restrictions.pattern && (!patternInput.value || patternInput.value.includes('авто'))) {
                patternInput.value = restrictions.pattern;
            } else if (!restrictions.pattern && fieldType === 'password') {
                // Для пароля УБИРАЕМ pattern, если он был установлен
                patternInput.value = '';
            }
            
            if (restrictions.minlength && (!minlengthInput.value || minlengthInput.value === '0')) {
                minlengthInput.value = restrictions.minlength;
            }
        }
        
        // События для автоматического обновления ограничений
        labelInput.addEventListener('input', updateAutoRestrictions);
        nameInput.addEventListener('input', updateAutoRestrictions);
        typeSelect.addEventListener('change', function() {
            updateAutoRestrictions();
            updateFieldParamsVisibility(this);
        });
        
        // Инициализация
        updateAutoRestrictions();
        updateFieldParamsVisibility(typeSelect);
    });
    
    // Обработка изменения типа существующих полей
    document.querySelectorAll('.field-type-select').forEach(select => {
        select.addEventListener('change', function() {
            updateFieldParamsVisibility(this);
        });
        
        // Инициализация при загрузке
        updateFieldParamsVisibility(select);
    });
    
    // Добавляем обработчики для существующих полей
    document.querySelectorAll('.field-label-input, .field-name-input').forEach(input => {
        input.addEventListener('input', function() {
            const fieldEditor = this.closest('.field-editor');
            const nameInput = fieldEditor.querySelector('.field-name-input');
            const labelInput = fieldEditor.querySelector('.field-label-input');
            const typeSelect = fieldEditor.querySelector('.field-type-select');
            const patternInput = fieldEditor.querySelector('.field-pattern-input');
            const minlengthInput = fieldEditor.querySelector('.field-minlength-input');
            
            if (nameInput && labelInput && typeSelect && patternInput && minlengthInput) {
                const restrictions = getAutoRestrictions(
                    nameInput.value, 
                    labelInput.value, 
                    typeSelect.value
                );
                
                // Обновляем только если текущие значения пустые или автоматические
                if (restrictions.pattern && (!patternInput.value || patternInput.value.includes('авто'))) {
                    patternInput.value = restrictions.pattern;
                } else if (!restrictions.pattern && typeSelect.value === 'password') {
                    // Для пароля УБИРАЕМ pattern
                    patternInput.value = '';
                }
                
                if (restrictions.minlength && (!minlengthInput.value || minlengthInput.value === '0')) {
                    minlengthInput.value = restrictions.minlength;
                }
            }
        });
    });
    
    // Удаление поля
    container.addEventListener('click', function(e) {
        if (e.target.classList.contains('remove-field')) {
            e.target.closest('.field-editor').remove();
            updateFieldNumbers();
        }
    });
    
    // Функция обновления видимости параметров
    function updateFieldParamsVisibility(selectElement) {
        const fieldInputs = selectElement.closest('.field-inputs');
        const fieldType = selectElement.value;
        
        // Скрываем все параметры
        fieldInputs.querySelectorAll('.field-option').forEach(option => {
            option.style.display = 'none';
        });
        
        // Показываем нужные параметры
        fieldInputs.querySelectorAll('.field-option').forEach(option => {
            const showFor = option.dataset.show.split(',');
            if (showFor.includes(fieldType)) {
                option.style.display = 'block';
            }
        });
    }
    
    // Функция обновления нумерации полей
    function updateFieldNumbers() {
        document.querySelectorAll('.field-editor').forEach((field, idx) => {
            const header = field.querySelector('.field-header h4');
            if (header) {
                const fieldName = field.querySelector('input[name$="[label]"]')?.value || 'Новое поле';
                header.textContent = `Поле ${idx + 1}: ${fieldName}`;
            }
        });
    }
    
    // Обновляем номер поля при изменении label
    container.addEventListener('input', function(e) {
        if (e.target.name && e.target.name.includes('[label]')) {
            const fieldEditor = e.target.closest('.field-editor');
            const fieldIndex = Array.from(container.children).indexOf(fieldEditor);
            const header = fieldEditor.querySelector('.field-header h4');
            if (header) {
                header.textContent = `Поле ${fieldIndex + 1}: ${e.target.value}`;
            }
        }
    });
});
</script>
<?php
?>