<?php
// VIEW: Страница форм входа
?>
<div class="wrap">
    <h1>Формы входа</h1>
    
    <div class="sa-login-forms-container">
        <!-- Редактор формы входа -->
        <div class="sa-form-editor">
            <h2><?php echo $editing_form ? 'Редактировать формы входа' : 'Создать новую форму входа'; ?></h2>
            
            <form method="post">
                <?php wp_nonce_field('sa_login_form_save'); ?>
                
                <div class="form-meta">
                    <p>
                        <label><strong>Название формы:</strong><br>
                            <input type="text" name="form_name" 
                                   value="<?php echo $editing_form ? esc_attr($editing_form['name']) : ''; ?>" 
                                   placeholder="Например: Основная форма входа" required>
                        </label>
                    </p>
                    
                    <p>
                        <label><strong>ID формы (английскими буквами):</strong><br>
                            <input type="text" name="form_id" 
                                   value="<?php echo $editing_form ? esc_attr($editing_form['id']) : ''; ?>" 
                                   pattern="[a-z0-9_]+" 
                                   placeholder="main_login" required>
                            <br><small>Шорткод будет: <code>[sa_login_<span id="login-shortcode-preview"><?php echo $editing_form ? esc_html($editing_form['id']) : 'ваш_id'; ?></span>]</code></small>
                        </label>
                    </p>
                    
                    <p>
                        <label><strong>Ссылка на форму регистрации:</strong><br>
                            <select name="registration_form">
                                <option value="">— Не добавлять ссылку —</option>
                                <?php foreach ($registration_forms as $reg_id => $reg_form): ?>
                                    <option value="<?php echo esc_attr($reg_id); ?>" 
                                        <?php selected($editing_form ? $editing_form['registration_form'] : '', $reg_id); ?>>
                                        <?php echo esc_html($reg_form['name']); ?> ([sa_register_<?php echo esc_html($reg_id); ?>])
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                    </p>
                    
                    <p>
                        <label><strong>Текст ссылки на регистрацию:</strong><br>
                            <input type="text" name="registration_text" 
                                   value="<?php echo $editing_form ? esc_attr($editing_form['registration_text']) : 'Еще не зарегистрированы? Регистрация'; ?>" 
                                   placeholder="Еще не зарегистрированы? Регистрация">
                        </label>
                    </p>
                </div>
                
                <h3>Стандартные поля формы входа:</h3>
                <ul>
                    <li><strong>Логин:</strong> текстовое поле (обязательное)</li>
                    <li><strong>Пароль:</strong> поле пароля (обязательное)</li>
                </ul>
                
                <div class="form-actions">
                    <input type="submit" name="sa_save_login_form" class="button button-primary button-large" 
                           value="<?php echo $editing_form ? 'Обновить форму' : 'Сохранить форму'; ?>">
                    <?php if ($editing_form): ?>
                        <a href="?page=sa_login_forms" class="button button-large">Отмена</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
        
        <!-- Список форм входа -->
        <div class="sa-forms-list">
            <h2>Сохранённые формы входа</h2>
            
            <?php if (empty($login_forms)): ?>
                <p>Нет сохранённых форм входа.</p>
            <?php else: ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Название</th>
                            <th>Шорткод</th>
                            <th>Ссылка на регистрацию</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($login_forms as $form_id => $form): ?>
                        <tr>
                            <td><strong><?php echo esc_html($form['name']); ?></strong></td>
                            <td><code>[sa_login_<?php echo esc_html($form_id); ?>]</code></td>
                            <td>
                                <?php if (!empty($form['registration_form'])): ?>
                                    Да (<?php echo esc_html($form['registration_text']); ?>)
                                <?php else: ?>
                                    Нет
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d.m.Y', strtotime($form['created'])); ?></td>
                            <td>
                                <a href="?page=sa_login_forms&edit=<?php echo esc_attr($form_id); ?>" class="button button-small">Редактировать</a>
                                <a href="?page=sa_login_forms&delete=<?php echo esc_attr($form_id); ?>" 
                                   class="button button-small" 
                                   onclick="return confirm('Удалить форму «<?php echo esc_js($form['name']); ?>»?')">Удалить</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Превью шорткода для формы входа
        const loginInput = document.querySelector('input[name="form_id"]');
        const loginPreview = document.getElementById('login-shortcode-preview');
        
        if (loginInput && loginPreview) {
            loginInput.addEventListener('input', function() {
                loginPreview.textContent = this.value || 'ваш_id';
            });
        }
    });
</script>
<?php
?>