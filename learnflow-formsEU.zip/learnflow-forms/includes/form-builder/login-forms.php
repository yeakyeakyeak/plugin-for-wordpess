<?php
// СТРАНИЦА ФОРМ ВХОДА
function sa_render_login_forms_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Нет прав для доступа.');
    }
    
    // Обработка сохранения формы входа
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sa_save_login_form'])) {
        sa_save_login_form();
    }
    
    // Обработка удаления формы
    if (isset($_GET['delete']) && !empty($_GET['delete'])) {
        $form_id = sanitize_key($_GET['delete']);
        $forms = get_option('sa_login_forms', []);
        
        if (isset($forms[$form_id])) {
            unset($forms[$form_id]);
            update_option('sa_login_forms', $forms);
            echo '<div class="updated"><p>Форма удалена.</p></div>';
        }
    }
    
    // Получаем все формы входа и регистрации
    $login_forms = get_option('sa_login_forms', []);
    $registration_forms = get_option('sa_registration_forms', []);
    
    // Если редактируем существующую форму
    $editing_form = null;
    if (isset($_GET['edit']) && !empty($_GET['edit']) && isset($login_forms[$_GET['edit']])) {
        $editing_form = $login_forms[$_GET['edit']];
    }
    
    // Выводим HTML
    require_once SA_PLUGIN_DIR . 'includes/form-builder/views/login-forms-view.php';
}

// Сохранение формы входа
function sa_save_login_form() {
    check_admin_referer('sa_login_form_save');
    
    $form_id = sanitize_key($_POST['form_id']);
    $form_name = sanitize_text_field($_POST['form_name']);
    $registration_form = sanitize_key($_POST['registration_form']);
    $registration_text = sanitize_text_field($_POST['registration_text']);
    
    // Сохраняем форму входа
    $login_forms = get_option('sa_login_forms', []);
    $login_forms[$form_id] = [
        'name' => $form_name,
        'id' => $form_id,
        'registration_form' => $registration_form,
        'registration_text' => $registration_text ?: 'Еще не зарегистрированы? Регистрация',
        'created' => current_time('mysql')
    ];
    update_option('sa_login_forms', $login_forms);
    
    echo '<div class="updated"><p>Форма входа "' . esc_html($form_name) . '" сохранена! Используйте шорткод: <code>[sa_login_' . esc_html($form_id) . ']</code></p></div>';
}
?>