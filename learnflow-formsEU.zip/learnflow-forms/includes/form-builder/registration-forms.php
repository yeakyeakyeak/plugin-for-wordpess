<?php
// СТРАНИЦА ФОРМ РЕГИСТРАЦИИ
function sa_render_registration_forms_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Нет прав для доступа.');
    }
    
    global $wpdb;
    
    // Обработка удаления формы
    if (isset($_GET['delete']) && !empty($_GET['delete'])) {
        $form_id = sanitize_key($_GET['delete']);
        $forms = get_option('sa_registration_forms', []);
        
        if (isset($forms[$form_id])) {
            unset($forms[$form_id]);
            update_option('sa_registration_forms', $forms);
            echo '<div class="updated"><p>Форма удалена.</p></div>';
        }
    }
    
    // Обработка сохранения формы
    $saved = false;
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sa_save_registration_form'])) {
        $saved = sa_save_registration_form();
    }
    
    // Получаем все формы регистрации
    $registration_forms = get_option('sa_registration_forms', []);
    
    // Если редактируем существующую форму
    $editing_form = null;
    if (isset($_GET['edit']) && !empty($_GET['edit']) && isset($registration_forms[$_GET['edit']])) {
        $editing_form = $registration_forms[$_GET['edit']];
    }
    
    // Выводим HTML
    require_once SA_PLUGIN_DIR . 'includes/form-builder/views/registration-forms-view.php';
}

// Обработка сохранения формы регистрации
function sa_save_registration_form() {
    check_admin_referer('sa_registration_form_save');
    
    $form_id = sanitize_key($_POST['form_id']);
    $form_name = sanitize_text_field($_POST['form_name']);
    $fields = isset($_POST['fields']) ? $_POST['fields'] : [];
    
    // Валидация и обработка полей
    $validated_fields = [];
    foreach ($fields as $index => $field) {
        if (!empty($field['name']) && !empty($field['label'])) {
            $validated_fields[] = sa_process_form_field($field);
        }
    }
    
    // Сохраняем форму
    $forms = get_option('sa_registration_forms', []);
    $forms[$form_id] = [
        'name' => $form_name,
        'id' => $form_id,
        'fields' => $validated_fields,
        'created' => current_time('mysql')
    ];
    update_option('sa_registration_forms', $forms);
    
    echo '<div class="updated"><p>Форма "' . esc_html($form_name) . '" сохранена! Используйте шорткод: <code>[sa_register_' . esc_html($form_id) . ']</code></p></div>';
    return true;
}

// Обработка поля формы
function sa_process_form_field($field) {
    require_once SA_PLUGIN_DIR . 'includes/validation/general-validation.php';
    require_once SA_PLUGIN_DIR . 'includes/validation/fio-validation.php';
    require_once SA_PLUGIN_DIR . 'includes/validation/phone-validation.php';
    
    $field_name = sanitize_key($field['name']);
    $field_label = $field['label'];
    
    // Определяем автоматические ограничения
    $auto_rules = sa_get_auto_field_rules($field_name, $field_label);
    
    // Обрабатываем pattern
    $pattern_value = '';
    if (!empty($field['pattern'])) {
        $pattern_value = stripslashes($field['pattern']);
        $pattern_value = trim($pattern_value, '/');
    } elseif (!empty($auto_rules['pattern'])) {
        $pattern_value = $auto_rules['pattern'];
    }
    
    return [
        'name' => $field_name,
        'label' => sanitize_text_field($field['label']),
        'type' => in_array($field['type'], ['text', 'password', 'email', 'tel', 'number', 'textarea', 'select', 'checkbox', 'radio', 'date']) 
                    ? $field['type'] : 'text',
        'placeholder' => sanitize_text_field($field['placeholder']),
        'required' => isset($field['required']) ? 1 : 0,
        'options' => !empty($field['options']) ? sanitize_text_field($field['options']) : '',
        'minlength' => !empty($field['minlength']) ? intval($field['minlength']) : (!empty($auto_rules['minlength']) ? $auto_rules['minlength'] : ''),
        'maxlength' => !empty($field['maxlength']) ? intval($field['maxlength']) : (!empty($auto_rules['maxlength']) ? $auto_rules['maxlength'] : ''),
        'pattern' => $pattern_value
    ];
}
?>