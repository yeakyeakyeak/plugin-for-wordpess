<?php
// ГЛАВНАЯ СТРАНИЦА КОНСТРУКТОРА ФОРМ
function sa_render_form_builder_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Нет прав для доступа.');
    }
    
    ?>
    <div class="wrap">
        <h1>Конструктор форм</h1>
        
        <div class="sa-dashboard">
            <div class="sa-dashboard-cards">
                <div class="sa-card">
                    <h2><span class="dashicons dashicons-forms"></span> Формы регистрации</h2>
                    <p>Создавайте кастомные формы регистрации пользователей с автоматическими ограничениями для стандартных полей.</p>
                    <a href="?page=sa_registration_forms" class="button button-primary">Управление формами</a>
                </div>
                
                <div class="sa-card">
                    <h2><span class="dashicons dashicons-lock"></span> Формы входа</h2>
                    <p>Создавайте формы для авторизации пользователей с ссылкой на регистрацию.</p>
                    <a href="?page=sa_login_forms" class="button button-primary">Управление формами</a>
                </div>
                
                <div class="sa-card">
                    <h2><span class="dashicons dashicons-clipboard"></span> Заявки на курсы</h2>
                    <p>Управляйте заявками пользователей на курсы.</p>
                    <a href="?page=sa_applications" class="button button-primary">Перейти к заявкам</a>
                </div>
            </div>
            
            <div class="sa-dashboard-info">
                <h2>Автоматические ограничения для стандартных полей:</h2>
                <ul>
                    <li><strong>Логин:</strong> латиница и цифры, не менее 6 символов</li>
                    <li><strong>Пароль:</strong> минимум 8 символов (любые символы)</li>
                    <li><strong>ФИО:</strong> кириллица, пробелы и дефисы. РОВНО 3 СЛОВА (Фамилия Имя Отчество)</li>
                    <li><strong>Телефон:</strong> формат 8(XXX)XXX-XX-XX</li>
                    <li><strong>Email:</strong> стандартный формат email</li>
                </ul>
                <p><em>Ограничения применяются автоматически при совпадении имени или метки поля (например: login, username, Логин).</em></p>
            </div>
        </div>
    </div>
    <?php
}
?>