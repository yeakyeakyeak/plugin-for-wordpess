<?php
// ГЛАВНАЯ СТРАНИЦА КОНСТРУКТОРА ФОРМ
function sa_render_form_builder_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Нет прав для доступа.');
    }
    
    ?>
    <div class="wrap">
        <h1>Конструктор форм</h1>
        
        <div class="sa-dashboard">
            <div class="sa-dashboard-cards">
                <div class="sa-card">
                    <h2><span class="dashicons dashicons-forms"></span> Формы регистрации</h2>
                    <p>Создавайте кастомные формы регистрации пользователей с автоматическими ограничениями для стандартных полей.</p>
                    <a href="?page=sa_registration_forms" class="button button-primary">Управление формами</a>
                </div>
                
                <div class="sa-card">
                    <h2><span class="dashicons dashicons-lock"></span> Формы входа</h2>
                    <p>Создавайте формы для авторизации пользователей с ссылкой на регистрацию.</p>
                    <a href="?page=sa_login_forms" class="button button-primary">Управление формами</a>
                </div>
                
                <div class="sa-card">
                    <h2><span class="dashicons dashicons-clipboard"></span> Заявки на курсы</h2>
                    <p>Управляйте заявками пользователей на курсы.</p>
                    <a href="?page=sa_applications" class="button button-primary">Перейти к заявкам</a>
                </div>
            </div>
            
            
        </div>
    </div>
    <?php
}
?>