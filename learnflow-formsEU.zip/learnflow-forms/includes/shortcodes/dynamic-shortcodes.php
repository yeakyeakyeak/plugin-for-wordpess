<?php
// ДИНАМИЧЕСКИЕ ШОРТКОДЫ

// Главная функция для регистрации шорткодов
function sa_init_dynamic_shortcodes()
{
    // Регистрация форм регистрации
    $registration_forms = get_option('sa_registration_forms', []);
    if (is_array($registration_forms)) {
        foreach ($registration_forms as $form_id => $form_data) {
            if (!empty($form_id)) {
                add_shortcode('sa_register_' . $form_id, function ($atts) use ($form_id, $form_data) {
                    return sa_render_registration_form($form_data);
                });
            }
        }
    }

    // Регистрация форм входа
    $login_forms = get_option('sa_login_forms', []);
    if (is_array($login_forms)) {
        foreach ($login_forms as $form_id => $form_data) {
            if (!empty($form_id)) {
                add_shortcode('sa_login_' . $form_id, function ($atts) use ($form_id, $form_data) {
                    return sa_render_login_form($form_data);
                });
            }
        }
    }

    // Статические шорткоды
    add_shortcode('sa_application_form', 'sa_application_form_shortcode');
    add_shortcode('sa_my_applications', 'sa_my_applications_shortcode');
}

// Инициализация при загрузке плагина
add_action('init', 'sa_init_dynamic_shortcodes');
