<?php
// ШОРТКОДЫ РЕГИСТРАЦИИ

// Рендеринг формы регистрации
function sa_render_registration_form($form_data) {
    if (is_user_logged_in()) {
        return '<p>Вы уже зарегистрированы и авторизованы.</p>';
    }
    
    ob_start();
    
    // Обработка отправки формы
    require_once SA_PLUGIN_DIR . 'includes/validation/general-validation.php';
    $result = sa_process_registration_form($form_data);
    
    if ($result['success']) {
        return '<div class="sa-registration-success"><p>Регистрация успешна! Вы автоматически вошли в систему.</p></div>';
    }
    
    // Выводим ошибки
    if (!empty($result['errors'])) {
        echo '<div class="sa-registration-errors">';
        foreach ($result['errors'] as $error) {
            echo '<p class="error">' . esc_html($error) . '</p>';
        }
        echo '</div>';
    }
    
    // Выводим форму
    require_once SA_PLUGIN_DIR . 'includes/shortcodes/views/registration-form-view.php';
    
    return ob_get_clean();
}

// Обработка формы регистрации
function sa_process_registration_form($form_data) {
    $errors = [];
    $success = false;
    
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sa_register_nonce'])) {
        if (wp_verify_nonce($_POST['sa_register_nonce'], 'sa_register_action_' . $form_data['id'])) {
            
            $user_data = [];
            $meta_data = [];
            
            foreach ($form_data['fields'] as $field) {
                $value = isset($_POST[$field['name']]) ? sanitize_text_field($_POST[$field['name']]) : '';
                
                // Базовые проверки
                $field_errors = sa_validate_field($field, $value);
                $errors = array_merge($errors, $field_errors);
                
                // Если ошибок нет, обрабатываем значение
                if (empty($field_errors)) {
                    $processed_value = sa_process_field_value($field, $value);
                    if ($processed_value !== $value) {
                        $value = $processed_value;
                        $_POST[$field['name']] = $value;
                    }
                    
                    // Собираем данные пользователя
                    $user_data = sa_collect_user_data($field, $value, $user_data);
                    if (!$user_data['is_user_field']) {
                        $meta_data[$field['name']] = $value;
                    }
                }
            }
            
            // Проверка обязательных полей для WordPress
            $required_errors = sa_validate_required_user_fields($user_data);
            $errors = array_merge($errors, $required_errors);
            
            // Проверка существования пользователя
            if (empty($errors)) {
                $existence_errors = sa_check_user_existence($user_data);
                $errors = array_merge($errors, $existence_errors);
            }
            
            // Регистрация
            if (empty($errors)) {
                $registration_result = sa_register_user($user_data, $meta_data);
                if ($registration_result['success']) {
                    $success = true;
                } else {
                    $errors[] = $registration_result['error'];
                }
            }
        }
    }
    
    return ['success' => $success, 'errors' => $errors];
}
?>