<?php
// VIEW: Форма регистрации
?>
<form method="post" class="sa-registration-form" id="sa-form-<?php echo esc_attr($form_data['id']); ?>" novalidate>
    <input type="hidden" name="form_id" value="<?php echo esc_attr($form_data['id']); ?>">
    <?php wp_nonce_field('sa_register_action_' . $form_data['id'], 'sa_register_nonce'); ?>
    
    <h3><?php echo esc_html($form_data['name']); ?></h3>
    
    <?php foreach ($form_data['fields'] as $field): 
        $value = isset($_POST[$field['name']]) ? esc_attr($_POST[$field['name']]) : '';
        $required = $field['required'] ? 'required' : '';
        $pattern_attr = '';
        $minlength_attr = !empty($field['minlength']) ? 'minlength="' . esc_attr($field['minlength']) . '"' : '';
        $maxlength_attr = !empty($field['maxlength']) ? 'maxlength="' . esc_attr($field['maxlength']) . '"' : '';
        $title = '';
        
        // Определяем тип поля для подсказок
        $field_lower_label = strtolower($field['label']);
        $field_lower_name = strtolower($field['name']);
        
        // Формируем подсказки
        if (strpos($field_lower_label, 'логин') !== false || 
            strpos($field_lower_name, 'login') !== false ||
            strpos($field_lower_name, 'username') !== false) {
            $title = 'Латиница и цифры, не менее 6 символов';
        }
        elseif (strpos($field_lower_label, 'пароль') !== false || 
                strpos($field_lower_name, 'password') !== false) {
            $title = 'Минимум 8 символов (любые символы)';
        }
        elseif (strpos($field_lower_label, 'фио') !== false || 
                strpos($field_lower_name, 'fio') !== false ||
                strpos($field_lower_name, 'full_name') !== false) {
            $title = 'Кириллица, пробелы и дефисы. Ровно 3 слова (Фамилия Имя Отчество)';
        }
        elseif (strpos($field_lower_label, 'телефон') !== false || 
                strpos($field_lower_name, 'phone') !== false ||
                strpos($field_lower_name, 'tel') !== false) {
            $title = 'Начинается с 8, 11 цифр (например: 89191234567)';
        }
        elseif ($field['type'] === 'email') {
            $title = 'Формат: example@mail.ru';
        }
        
        // Для телефона не используем pattern, так как будет автоформатирование
        if (!empty($field['pattern']) && $field['type'] !== 'tel') {
            $html_pattern = $field['pattern'];
            $html_pattern = preg_replace('/^\/(.*)\/[a-z]*$/i', '$1', $html_pattern);
            $html_pattern = htmlspecialchars($html_pattern, ENT_QUOTES);
            $pattern_attr = 'pattern="' . $html_pattern . '"';
        }
    ?>
        <div class="form-field">
            <label>
                <?php echo esc_html($field['label']); ?>
                <?php if ($field['required']): ?>
                    <span class="required">*</span>
                <?php endif; ?>
            </label>
            
            <?php if ($field['type'] === 'textarea'): ?>
                <textarea name="<?php echo esc_attr($field['name']); ?>" 
                          placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                          title="<?php echo esc_attr($title); ?>"
                          <?php echo $required; ?> <?php echo $minlength_attr; ?> <?php echo $maxlength_attr; ?>><?php echo $value; ?></textarea>
            
            <?php elseif ($field['type'] === 'select'): ?>
                <select name="<?php echo esc_attr($field['name']); ?>" <?php echo $required; ?>>
                    <option value=""><?php echo esc_html($field['placeholder'] ?: 'Выберите...'); ?></option>
                    <?php if (!empty($field['options'])): 
                        $options = explode(',', $field['options']);
                        foreach ($options as $option):
                            $option = trim($option);
                    ?>
                        <option value="<?php echo esc_attr($option); ?>" <?php selected($value, $option); ?>>
                            <?php echo esc_html($option); ?>
                        </option>
                    <?php endforeach; endif; ?>
                </select>
            
            <?php elseif ($field['type'] === 'checkbox'): ?>
                <label class="checkbox-label">
                    <input type="checkbox" name="<?php echo esc_attr($field['name']); ?>" value="1" 
                           <?php checked($value, '1'); ?> <?php echo $required; ?>>
                    <?php echo esc_html($field['placeholder'] ?: 'Да'); ?>
                </label>
            
            <?php elseif ($field['type'] === 'radio' && !empty($field['options'])): ?>
                <div class="radio-group">
                    <?php $options = explode(',', $field['options']);
                    foreach ($options as $option):
                        $option = trim($option);
                    ?>
                        <label class="radio-label">
                            <input type="radio" name="<?php echo esc_attr($field['name']); ?>" 
                                   value="<?php echo esc_attr($option); ?>" 
                                   <?php checked($value, $option); ?> <?php echo $required; ?>>
                            <?php echo esc_html($option); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            
            <?php else: ?>
                <input type="<?php echo esc_attr($field['type']); ?>" 
                       name="<?php echo esc_attr($field['name']); ?>" 
                       value="<?php echo $value; ?>"
                       placeholder="<?php echo esc_attr($field['placeholder']); ?>"
                       title="<?php echo esc_attr($title); ?>"
                       <?php echo $required; ?> 
                       <?php echo $pattern_attr; ?>
                       <?php echo $minlength_attr; ?>
                       <?php echo $maxlength_attr; ?>
                       <?php if ($field['type'] === 'tel'): ?>class="phone-input"<?php endif; ?>>
            <?php endif; ?>
            
            <?php if (!empty($title)): ?>
                <div class="field-hint"><?php echo esc_html($title); ?></div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    
    <div class="form-submit">
        <button type="submit" class="sa-submit-button">Создать пользователя</button>
    </div>
</form>
<?php
?>