<?php
// ШОРТКОДЫ ДЛЯ ЗАЯВОК

// Форма заявки на курсы
function sa_application_form_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>Пожалуйста, войдите для подачи заявки.</p>';
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'survival_applications';
    $msg = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sa_application_nonce']) && wp_verify_nonce($_POST['sa_application_nonce'], 'sa_application_action')) {
        $course_options = [
            'Основы алгоритмизации и программирования',
            'Основы веб-дизайна',
            'Основы проектирования баз данных',
        ];
        $course_name = sanitize_text_field($_POST['course_name']);
        $start_date_raw = sanitize_text_field($_POST['start_date']);
        $payment_method = sanitize_text_field($_POST['payment_method']);

        $date_parts = explode('.', $start_date_raw);
        $start_date = null;
        if (count($date_parts) === 3) {
            $start_date = sprintf('%04d-%02d-%02d', $date_parts[2], $date_parts[1], $date_parts[0]);
        }

        if (!in_array($course_name, $course_options)) {
            $msg = '<p style="color:red;">Выберите корректный курс.</p>';
        } elseif (!$start_date) {
            $msg = '<p style="color:red;">Некорректная дата начала обучения.</p>';
        } elseif (!in_array($payment_method, ['Наличными', 'Перевод по номеру телефона'])) {
            $msg = '<p style="color:red;">Выберите способ оплаты.</p>';
        } else {
            $wpdb->insert($table_name, [
                'user_id' => get_current_user_id(),
                'course_name' => $course_name,
                'start_date' => $start_date,
                'payment_method' => $payment_method,
                'status' => 'Новая',
                'created_at' => current_time('mysql'),
            ]);
            $msg = '<p style="color:green;">Заявка отправлена на рассмотрение администратору.</p>';
        }
    }

    ob_start();
    echo $msg;
    ?>
    <form method="post" novalidate style="max-width: 500px; margin: 20px auto; padding: 20px; background: #f9f9f9; border: 1px solid #ddd;">
        <h3>Заявка на курс</h3>
        <p>
            <select name="course_name" required style="width: 100%; padding: 10px;">
                <option value="">Выберите курс</option>
                <option value="Основы алгоритмизации и программирования">Основы алгоритмизации и программирования</option>
                <option value="Основы веб-дизайна">Основы веб-дизайна</option>
                <option value="Основы проектирования баз данных">Основы проектирования баз данных</option>
            </select>
        </p>
        <p><input type="text" name="start_date" placeholder="Дата начала (ДД.ММ.ГГГГ)" required pattern="\d{2}\.\d{2}\.\d{4}" style="width: 100%; padding: 10px;"></p>
        <p>
            <select name="payment_method" required style="width: 100%; padding: 10px;">
                <option value="">Выберите способ оплаты</option>
                <option value="Наличными">Наличными</option>
                <option value="Перевод по номеру телефона">Перевод по номеру телефона</option>
            </select>
        </p>
        <?php wp_nonce_field('sa_application_action', 'sa_application_nonce'); ?>
        <p><input type="submit" value="Отправить" style="background: #0073aa; color: white; border: none; padding: 12px 25px; cursor: pointer;"></p>
    </form>
    <?php
    return ob_get_clean();
}

// Мои заявки
function sa_my_applications_shortcode() {
    if (!is_user_logged_in()) {
        return '<p>Пожалуйста, войдите для просмотра своих заявок.</p>';
    }

    global $wpdb;
    $table_apps = $wpdb->prefix . 'survival_applications';
    $table_feedback = $wpdb->prefix . 'survival_app_feedback';
    $user_id = get_current_user_id();

    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sa_feedback_nonce']) && wp_verify_nonce($_POST['sa_feedback_nonce'], 'sa_feedback_action')) {
        $app_id = intval($_POST['application_id']);
        $feedback_text = sanitize_textarea_field($_POST['feedback_text']);
        if ($feedback_text) {
            $wpdb->insert($table_feedback, [
                'application_id' => $app_id,
                'feedback_text' => $feedback_text,
                'created_at' => current_time('mysql'),
            ]);
            $msg = '<p style="color:green;">Отзыв добавлен.</p>';
        } else {
            $msg = '<p style="color:red;">Отзыв не может быть пустым.</p>';
        }
    }

    $applications = $wpdb->get_results($wpdb->prepare(
        "SELECT a.*, f.feedback_text FROM $table_apps a LEFT JOIN $table_feedback f ON a.id = f.application_id WHERE a.user_id = %d ORDER BY a.created_at DESC",
        $user_id
    ));

    ob_start();
    echo $msg;
    if (empty($applications)) {
        echo '<p>У вас нет заявок на курсы.</p>';
    } else {
        foreach ($applications as $app) {
            echo '<div style="border:1px solid #ccc;padding:15px;margin-bottom:20px;background:#fff;">';
            echo '<h4 style="margin-top:0;">' . esc_html($app->course_name) . '</h4>';
            echo '<p><strong>Дата начала:</strong> ' . esc_html(date('d.m.Y', strtotime($app->start_date))) . '</p>';
            echo '<p><strong>Способ оплаты:</strong> ' . esc_html($app->payment_method) . '</p>';
            echo '<p><strong>Статус:</strong> ' . esc_html($app->status) . '</p>';
            echo '<p><strong>Отзыв:</strong> ' . ($app->feedback_text ? esc_html($app->feedback_text) : 'Отзыв не оставлен') . '</p>';

            if (!$app->feedback_text) {
                echo '<form method="post" style="margin-top:15px;">';
                wp_nonce_field('sa_feedback_action', 'sa_feedback_nonce');
                echo '<input type="hidden" name="application_id" value="' . esc_attr($app->id) . '">';
                echo '<textarea name="feedback_text" rows="3" style="width:100%;" placeholder="Оставьте отзыв"></textarea><br>';
                echo '<input type="submit" value="Отправить отзыв" style="margin-top:10px;">';
                echo '</form>';
            }
            echo '</div>';
        }
    }
    return ob_get_clean();
}
?>