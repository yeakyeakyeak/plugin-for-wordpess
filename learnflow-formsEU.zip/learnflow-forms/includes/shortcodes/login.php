<?php
// ШОРТКОДЫ ВХОДА

// Рендеринг формы входа
function sa_render_login_form($form_data) {
    if (is_user_logged_in()) {
        return '<p>Вы уже авторизованы.</p>';
    }
    
    ob_start();
    
    // Обработка входа
    $error = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sa_login_nonce'])) {
        if (wp_verify_nonce($_POST['sa_login_nonce'], 'sa_login_action_' . $form_data['id'])) {
            $username = sanitize_user($_POST['username']);
            $password = $_POST['password'];
            
            $creds = array(
                'user_login'    => $username,
                'user_password' => $password,
                'remember'      => false
            );
            
            $user = wp_signon($creds, false);
            
            if (is_wp_error($user)) {
                $error = 'Неверный логин или пароль.';
            } else {
                wp_redirect(home_url());
                exit;
            }
        }
    }
    
    ?>
    <form method="post" class="sa-login-form" id="sa-login-<?php echo esc_attr($form_data['id']); ?>" novalidate>
        <input type="hidden" name="form_id" value="<?php echo esc_attr($form_data['id']); ?>">
        <?php wp_nonce_field('sa_login_action_' . $form_data['id'], 'sa_login_nonce'); ?>
        
        <h3><?php echo esc_html($form_data['name']); ?></h3>
        
        <?php if ($error): ?>
            <div class="sa-login-error">
                <p><?php echo esc_html($error); ?></p>
            </div>
        <?php endif; ?>
        
        <div class="form-field">
            <label>Логин:</label>
            <input type="text" name="username" required>
        </div>
        
        <div class="form-field">
            <label>Пароль:</label>
            <input type="password" name="password" required>
        </div>
        
        <div class="form-submit">
            <button type="submit" class="sa-submit-button">Войти</button>
        </div>
        
        <?php if (!empty($form_data['registration_form'])): ?>
            <div class="registration-link">
                <a href="javascript:void(0)" onclick="document.getElementById('sa-form-<?php echo esc_attr($form_data['registration_form']); ?>').scrollIntoView({behavior: 'smooth'})">
                    <?php echo esc_html($form_data['registration_text']); ?>
                </a>
            </div>
        <?php endif; ?>
    </form>
    <?php
    
    return ob_get_clean();
}
?>